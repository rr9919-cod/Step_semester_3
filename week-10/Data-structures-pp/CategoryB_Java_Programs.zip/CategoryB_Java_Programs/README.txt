CATEGORY B — JAVA PROGRAMS

This ZIP contains five separate Java source files for Part A coding problems from CATEGORY-B-DS_PRACTICE.pdf.

Files:
1. Problem1_BankAccountWithdrawalSystem.java
2. Problem2_CampusVehiclePassSystem.java
3. Problem3_StudentClubRegistrationManagement.java
4. Problem4_ClassMarksGridAnalysis.java
5. Problem5_PayrollRegisterSystem.java

How to compile and run (Windows Command Prompt / VS Code terminal):
1. Open the extracted folder.
2. Compile one program, for example:
   javac Problem1_BankAccountWithdrawalSystem.java
3. Run it:
   java Problem1_BankAccountWithdrawalSystem
4. Type or paste the sample input, then press Ctrl+Z and Enter in Windows to signal end of input.
   (In the VS Code terminal, you can also run it and paste the complete input followed by Ctrl+Z, Enter.)

Each file contains its own public class, so the filename must match the class name.
